/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB30/SessionRemote.java to edit this template
 */
package UEFA;

import java.util.List;
import javax.ejb.Remote;

/**
 *
 * @author Antonio
 */
@Remote
public interface PartitaEJBRemote {
    void aggiungiPartita(Partita p);
    Partita aggiornaPartita(Partita p);
    void rimuoviPartita(Partita p);
    
    Partita trovaPerId(int id);
    List<Partita> trovaPerTipoPartita(String tipo_partita);
    List<Partita> trovaPerNumeroAmmonizioni(int numero_ammonizioni);
    List<Partita> trovaPerNumeroEspulsioni(int numero_espulsioni);
    List<Partita> trovaPerNumeroGoal(int numero_goal);
    List<Partita> trovaTutte();
}
