/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB31/SingletonEjbClass.java to edit this template
 */
package UEFA;

import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.annotation.sql.DataSourceDefinition;
import javax.inject.Inject;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

/**
 *
 * @author Antonio
 */
@Singleton
@Startup
@DataSourceDefinition(
    name = "java:global/jdbc/UEFADS",
    databaseName = "EsameDB",
    user = "Anthony", password = "DemonSlayer",
    className = "org.apache.derby.jdbc.EmbeddedDataSource"
    )

public class DatabasePopulator {
    @Inject
    private PartitaEJB ejb;
    private Partita p1, p2, p3, p4;
    }
