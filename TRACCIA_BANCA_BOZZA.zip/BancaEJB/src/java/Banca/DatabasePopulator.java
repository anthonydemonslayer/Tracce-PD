/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB31/SingletonEjbClass.java to edit this template
 */
package Banca;

import javax.ejb.*;
import javax.annotation.*;
import javax.annotation.sql.*;
import javax.inject.Inject;


/**
 *
 * @author Antonio
 */
@Singleton
@Startup
@DataSourceDefinition(
    name = "java:global/jdbc/BancaDS",
    user = "Anthony", password = "DemonSlayer",
    databaseName = "EsameDB",
    className = "org.apache.derby.jdbc.EmbeddedDataSource",
    properties = {"connectionAttribute=;create=true"}
)
public class DatabasePopulator {

    @Inject
    private CorrentistaEJB ejb;
    private Correntista c1, c2, c3;
    
    @PostConstruct
    private void PopulateDB() {
        c1 = new Correntista(1, "Renzi", "Matteo", "Politico", "SI", 5000, 3, 7000, 10, 900000f, 3000f);
        c2 = new Correntista(2, "Briatore", "Flavio", "Imprenditore", "NO", 10, 200, 500, 1000, 5000f, 100000f);
        c3 = new Correntista(3, "Bergoglio", "Francesco", "Papa", "NO", 10, 10, 10, 10, 500f, 500f);
        
        ejb.aggiungiCorrentista(c1);
        ejb.aggiungiCorrentista(c2);
        ejb.aggiungiCorrentista(c3);
        
    }
    
    @PreDestroy
    private void clearDB(){
        ejb.rimuoviCorrentista(c1);
        ejb.rimuoviCorrentista(c2);
        ejb.rimuoviCorrentista(c3);
        
    }
}
