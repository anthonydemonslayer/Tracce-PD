/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Banca;
import javax.persistence.*;
import javax.enterprise.inject.*;

/**
 *
 * @author Antonio
 */
public class DatabaseProducer {
    @Produces
    @PersistenceContext(unitName = "BancaPU")
    private EntityManager em;
}
