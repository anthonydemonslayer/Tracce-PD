/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Banca;

import java.io.Serializable;
import javax.persistence.*;
import javax.xml.bind.annotation.XmlRootElement;
import static Banca.Correntista.*;

/**
 *
 * @author Antonio
 */
@Entity
@NamedQueries({ 
    @NamedQuery(name = TROVA_PER_COGNOME, query = "SELECT c FROM Correntista c WHERE c.cognome=:cognome"),
    @NamedQuery(name = TROVA_PER_IMPIEGO, query = "SELECT c FROM Correntista c WHERE c.impiego=?1"),
    @NamedQuery(name = TROVA_TUTTI, query = "SELECT c FROM Correntista c"),
    @NamedQuery(name = TROVA_PER_INSOLVENZA, query = "SELECT c FROM Correntista c WHERE c.insolvente=:insolvenza"),
    @NamedQuery(name = TROVA_PER_ID, query = "SELECT c FROM Correntista c WHERE c.id=:id"),
    @NamedQuery(name = TROVA_PER_BONIFICI_INGRESSO, query = "SELECT c FROM Correntista c WHERE c.num_bonifici_ingresso>:num_bonifici_ingresso"),
    @NamedQuery(name = TROVA_PER_OPERAZIONI, query = "SELECT c FROM Correntista c WHERE (c.operazioni_ingresso+c.operazioni_uscita)>?1")
})

@XmlRootElement
public class Correntista implements Serializable {
    public static final String TROVA_TUTTI = "Correntista.trovaTutti";
    public static final String TROVA_PER_COGNOME = "Correntista.trovaPerCognome";
    public static final String TROVA_PER_IMPIEGO = "Correntista.trovaPerImpiego";
    public static final String TROVA_PER_INSOLVENZA = "Correntista.trovaPerInsolvenza";
    public static final String TROVA_PER_ID = "Correntista.trovaPerId";
    public static final String TROVA_PER_BONIFICI_INGRESSO = "Correntista.trovaPerBonificiIngresso";
    public static final String TROVA_PER_OPERAZIONI = "Correntista.trovaPerOperazioni";
    
    
    @Id
    
    private int id;
    private String cognome;
    private String nome;
    private String impiego;
    private String insolvente;
    private Integer num_bonifici_ingresso;
    private Integer num_bonifici_uscita;
    private Integer operazioni_ingresso;
    private Integer operazioni_uscita;
    private Float importo_ingresso;
    private Float importo_uscita;

    public Correntista() {
    }

    public Correntista(int id, String cognome, String nome, String impiego, String insolvente, Integer num_bonifici_ingresso, Integer num_bonifici_uscita, Integer operazioni_ingresso, Integer operazioni_uscita, Float importo_ingresso, Float importo_uscita) {
        this.id = id;
        this.cognome = cognome;
        this.nome = nome;
        this.impiego = impiego;
        this.insolvente = insolvente;
        this.num_bonifici_ingresso = num_bonifici_ingresso;
        this.num_bonifici_uscita = num_bonifici_uscita;
        this.operazioni_ingresso = operazioni_ingresso;
        this.operazioni_uscita = operazioni_uscita;
        this.importo_ingresso = importo_ingresso;
        this.importo_uscita = importo_uscita;
    }
    
    public int getId() {
        return id;
    }

    public String getCognome() {
        return cognome;
    }

    public String getNome() {
        return nome;
    }

    public String getImpiego() {
        return impiego;
    }

    public String getInsolvente() {
        return insolvente;
    }

    public Integer getNum_bonifici_ingresso() {
        return num_bonifici_ingresso;
    }

    public Integer getNum_bonifici_uscita() {
        return num_bonifici_uscita;
    }

    public Integer getOperazioni_ingresso() {
        return operazioni_ingresso;
    }

    public Integer getOperazioni_uscita() {
        return operazioni_uscita;
    }

    public Float getImporto_ingresso() {
        return importo_ingresso;
    }

    public Float getImporto_uscita() {
        return importo_uscita;
    }
    
    public void setId(int id) {
        this.id = id;
    }

    public void setCognome(String cognome) {
        this.cognome = cognome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setImpiego(String impiego) {
        this.impiego = impiego;
    }

    public void setInsolvente(String insolvente) {
        this.insolvente = insolvente;
    }

    public void setNum_bonifici_ingresso(Integer num_bonifici_ingresso) {
        this.num_bonifici_ingresso = num_bonifici_ingresso;
    }

    public void setNum_bonifici_uscita(Integer num_bonifici_uscita) {
        this.num_bonifici_uscita = num_bonifici_uscita;
    }

    public void setOperazioni_ingresso(Integer operazioni_ingresso) {
        this.operazioni_ingresso = operazioni_ingresso;
    }

    public void setOperazioni_uscita(Integer operazioni_uscita) {
        this.operazioni_uscita = operazioni_uscita;
    }

    public void setImporto_ingresso(Float importo_ingresso) {
        this.importo_ingresso = importo_ingresso;
    }

    public void setImporto_uscita(Float importo_uscita) {
        this.importo_uscita = importo_uscita;
    }

    @Override
    public String toString() {
        return "Correntista{" + "id=" + id + ", cognome=" + cognome + ", nome=" + nome + ", impiego=" + impiego + ", insolvente=" + insolvente + ", num_bonifici_ingresso=" + num_bonifici_ingresso + ", num_bonifici_uscita=" + num_bonifici_uscita + ", operazioni_ingresso=" + operazioni_ingresso + ", operazioni_uscita=" + operazioni_uscita + ", importo_ingresso=" + importo_ingresso + ", importo_uscita=" + importo_uscita + '}';
    }
    
}
