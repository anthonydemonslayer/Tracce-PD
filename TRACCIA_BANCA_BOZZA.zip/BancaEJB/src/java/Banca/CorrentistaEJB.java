/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB30/StatelessEjbClass.java to edit this template
 */
package Banca;

import java.util.List;
import javax.ejb.*;
import javax.persistence.*;
import javax.jws.*;
import javax.inject.Inject;

/**
 *
 * @author Antonio
 */
@Stateless
@LocalBean
@WebService
@Counter

public class CorrentistaEJB implements CorrentistaEJBRemote {

    @Inject
    private EntityManager em;

    @Override
    public void aggiungiCorrentista(Correntista c) {
        em.persist(c);
    }

    @Override
    public void aggiornaCorrentista(Correntista c) {
        em.merge(c);
    }

    @Override
    public void rimuoviCorrentista(Correntista c) {
        em.remove(c);
    }

    @Override
    public List<Correntista> getCorrentisti() {
        TypedQuery<Correntista> query = em.createNamedQuery(Correntista.TROVA_TUTTI, Correntista.class);
        return query.getResultList();
    }

    @Override
    public List<Correntista> getPerCognome(String cognome) {
        TypedQuery<Correntista> query = em.createNamedQuery(Correntista.TROVA_PER_COGNOME, Correntista.class);
        query.setParameter("cognome", cognome);
        return query.getResultList();
    }

    @Override
    public List<Correntista> getPerInsolvenza(String insolvenza) {
        TypedQuery<Correntista> query = em.createNamedQuery(Correntista.TROVA_PER_INSOLVENZA, Correntista.class);
        query.setParameter("insolvenza", insolvenza);
        return query.getResultList();
    }

    @Override
    public List<Correntista> getPerImpiego(String impiego) {
        TypedQuery<Correntista> query = em.createNamedQuery(Correntista.TROVA_PER_IMPIEGO, Correntista.class);
        query.setParameter("impiego", impiego);
        return query.getResultList();
    }

    @Override
    public List<Correntista> getPerOperazioni(Integer operazioni) {
        TypedQuery<Correntista> query = em.createNamedQuery(Correntista.TROVA_PER_OPERAZIONI, Correntista.class);
        query.setParameter("operazioni", operazioni);
        return query.getResultList();
    }

    @Override
    public List<Correntista> getPerBonificiInIngresso(Integer bonifici_ingresso) {
        TypedQuery<Correntista> query = em.createNamedQuery(Correntista.TROVA_PER_BONIFICI_INGRESSO, Correntista.class);
        query.setParameter("bonifici_ingresso", bonifici_ingresso);
        return query.getResultList();
    }

    @Override
    public Correntista getCorrentista(Integer id) {
        TypedQuery<Correntista> query = em.createNamedQuery(Correntista.TROVA_PER_ID, Correntista.class);
        query.setParameter("id", id);
        return query.getSingleResult();
    }

    @Override
    @CheckParameters
    public boolean effettua_bonifico(Integer id, Float importo) {
        Correntista c = getCorrentista(id);
        c.setNum_bonifici_uscita(c.getNum_bonifici_uscita()+1);
        c.setOperazioni_uscita(c.getOperazioni_uscita()+1);
        c.setImporto_uscita(importo+c.getImporto_uscita()+1);
        return true;
    }
    
    
    
}
