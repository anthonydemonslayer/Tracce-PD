/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB30/SessionRemote.java to edit this template
 */
package Banca;

import java.util.List;
import javax.ejb.Remote;

/**
 *
 * @author Antonio
 */
@Remote
public interface CorrentistaEJBRemote {
    
    void aggiungiCorrentista(Correntista c);
    void aggiornaCorrentista(Correntista c);
    void rimuoviCorrentista(Correntista c);
    
    List<Correntista> getCorrentisti();
    List<Correntista> getPerCognome(String cognome);
    List<Correntista> getPerInsolvenza(String insolvenza);
    List<Correntista> getPerImpiego(String impiego);
    List<Correntista> getPerOperazioni(Integer operazioni);
    List<Correntista> getPerBonificiInIngresso(Integer bonifici_ingresso);
    Correntista getCorrentista(Integer id);
    
    boolean effettua_bonifico(Integer id, Float importo);
    
}
