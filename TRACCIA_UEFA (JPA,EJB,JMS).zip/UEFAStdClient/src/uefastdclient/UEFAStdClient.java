/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package uefastdclient;

/**
 *
 * @author Antonio
 */
import java.util.List;
import javax.naming.*;
import UEFA.*;

public class UEFAStdClient {

    private static PartitaEJBRemote ejb;
    
    public static void main(String [] args) throws NamingException {
        Context ctx = new InitialContext();
        ejb = (PartitaEJBRemote) ctx.lookup("java:global/UEFA/PartitaEJB!UEFA.PartitaEJBRemote");
        
        System.out.println("Partita con più di 2 goal");
        List<Partita> lista = ejb.trovaPerNumeroGoal(2);
        for(Partita p:lista)
            System.out.println(p);
        
        System.out.println("Partita con 0 ammonizioni");
        lista = ejb.trovaPerNumeroAmmonizioni(0);
        for(Partita p:lista)
            System.out.println(p);
        
    }
    
    
}
